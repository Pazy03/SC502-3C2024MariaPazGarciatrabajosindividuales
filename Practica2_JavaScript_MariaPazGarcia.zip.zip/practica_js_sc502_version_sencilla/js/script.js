function calcularSalario() {
    let salario = Number(document.getElementById("salario").value);

    if (salario <= 0) {
        document.getElementById("resultadoSalario").innerHTML = "Ingrese un salario válido";
        return;
    }

    let cargas = salario * 0.1083;
    let renta = 0;

    if (salario > 918000 && salario <= 1347000) {
        renta = (salario - 918000) * 0.10;
    } else if (salario > 1347000 && salario <= 2364000) {
        renta = (1347000 - 918000) * 0.10;
        renta = renta + ((salario - 1347000) * 0.15);
    } else if (salario > 2364000 && salario <= 4727000) {
        renta = (1347000 - 918000) * 0.10;
        renta = renta + ((2364000 - 1347000) * 0.15);
        renta = renta + ((salario - 2364000) * 0.20);
    } else if (salario > 4727000) {
        renta = (1347000 - 918000) * 0.10;
        renta = renta + ((2364000 - 1347000) * 0.15);
        renta = renta + ((4727000 - 2364000) * 0.20);
        renta = renta + ((salario - 4727000) * 0.25);
    }

    let neto = salario - cargas - renta;

    document.getElementById("resultadoSalario").innerHTML =
        "Cargas sociales: ₡" + cargas.toFixed(2) + "<br>" +
        "Impuesto de renta: ₡" + renta.toFixed(2) + "<br>" +
        "Salario neto: ₡" + neto.toFixed(2);
}

function cambiarTexto() {
    document.getElementById("parrafo").innerHTML = "El párrafo fue cambiado con JavaScript.";
}

function validarEdad() {
    let edad = Number(document.getElementById("edad").value);

    if (edad > 18) {
        document.getElementById("resultadoEdad").innerHTML = "Eres mayor de edad.";
    } else {
        document.getElementById("resultadoEdad").innerHTML = "Eres menor de edad.";
    }
}

function mostrarEstudiantes() {
    let estudiantes = [
        { nombre: "Maria Paz", apellido: "Garcia", nota: 90 },
        { nombre: "Emily", apellido: "Acuña", nota: 88 },
        { nombre: "Yustin", apellido: "Torres", nota: 85 },
        { nombre: "Fabian", apellido: "Bustamante", nota: 92 }
    ];

    let texto = "";
    let suma = 0;

    estudiantes.forEach(function(est) {
        texto = texto + est.nombre + " " + est.apellido + "<br>";
        suma = suma + est.nota;
    });

    let promedio = suma / estudiantes.length;

    texto = texto + "<br>Promedio: " + promedio.toFixed(2);

    document.getElementById("resultadoEstudiantes").innerHTML = texto;
}
